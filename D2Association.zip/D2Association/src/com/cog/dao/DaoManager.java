package com.cog.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.cog.entity.Address;
import com.cog.entity.Author;
import com.cog.entity.Book;
import com.cog.entity.Course;
import com.cog.entity.Customer;
import com.cog.entity.Player;
import com.cog.entity.Team;
import com.cog.entity.Trainee;
import com.cog.resources.HibernateUtil;

public class DaoManager {

	private SessionFactory factory;
	private Session session;
	private boolean status;
	public DaoManager()
	{
		factory = HibernateUtil.GetFactory();
	}
	
	public boolean AddCusAddress(Customer cus,Address add)
	{
		
		session=factory.openSession();
		session.beginTransaction();
		try{
			
			session.persist(add);
			cus.setAddress(add);
			session.persist(cus);
			session.getTransaction().commit();
			status=true;
			
		}catch(HibernateException ex){
			session.getTransaction().rollback();
		}
		session.close();
		return status;
	}
	
	/*
	public Query getAll()
	{
		session=factory.openSession();
		return session.createQuery("select cust.cusId,cust.name,addr.city,addr.street from Customer cust inner join cust.address addr");
	}
	
	 public Query getAllBook_Author()
	{
		session=factory.openSession();
		return session.createQuery("select cust.cusId,cust.name,addr.city,addr.street from Customer cust inner join cust.address addr");
	}
	*/
	
	 /*
		 * 
		 * 
		 * 
		 *
	public boolean updateCustomer(int Id){
		
		boolean status=false;
		Customer rm= (Customer) session.get(Customer.class, Id);
		Address a1=new Address();
		
		//rm.setCapacity(66);
		//rm.setSys_AVL(false);
		a1.setCity("TN");
		rm.setAddress(a1);
		session.beginTransaction();
		try{
			session.update(rm);
			session.getTransaction().commit();
			status = true;
		}catch(HibernateException ex1)
		{
			session.getTransaction().rollback();
		}
		session.close();
		return status;
	}
		
	*/	
	
	public boolean AddBook_Author(Book book,Author auth)
	{
		
		session=factory.openSession();
		session.beginTransaction();
		try{
			
			//auth.setBook(book);
			book.setAuth(auth);
			auth.setBook(book);
			session.save(book);
			session.getTransaction().commit();
			status = true;
		}catch(HibernateException ex){
			session.getTransaction().rollback();
		}
		session.close();
		return status;
	}
	
	
	//******ONE-TO-MANY
	
	public boolean AddTeam_Player(Team team,List<Player> plist)
	{
		Player play=new Player();
		session=factory.openSession();
		session.beginTransaction();
		try{
			
			//auth.setBook(book);
			team.setPlayer(plist);
			play.setTeam(team);
			session.save(team);
			session.getTransaction().commit();
			status = true;
		}catch(HibernateException ex){
			session.getTransaction().rollback();
		}
		session.close();
		return status;
	}

	 public List<Team> getAllTeam_Players()
		{
			session=factory.openSession();
			//return session.createQuery("select tt.TeamId,tt.TName,pp.PName from "
				//	+ "Team tt inner join Team.player pp");
					return session.createQuery("from Team").list();		
					
		}
	
	
	 
	 //MANYTOMANY
	 
	 public boolean AddTrainee_Course(List<Trainee> tralist,List<Course> clist)
		{
		
			session=factory.openSession();
			session.beginTransaction();
			try{
				for(Trainee t:tralist){
					t.setClist(clist);
					session.save(t);
				}
				
				//session.save();
				session.getTransaction().commit();
				status = true;
			}catch(HibernateException ex){
				session.getTransaction().rollback();
				status=false;
			}
			session.close();
			return status;
		}
	 
	 
	 
	 
}
