package com.cog.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.cog.entity.Address;
import com.cog.entity.Customer;
import com.cog.entity.Event;
import com.cog.entity.Participants;
import com.cog.entity.Room;
import com.cog.resources.HibernateUtil;

public class EventManager {

	private SessionFactory factory;
	private Session session;
	private boolean status;
	public EventManager()
	{
		factory = HibernateUtil.GetFactory();
	}
	
	public boolean AddRoom_Event(Room room,Event event)
	{
		
		session=factory.openSession();
		session.beginTransaction();
		try{
			
			session.save(event);
			room.setEvent(event);
			session.save(room);
			session.getTransaction().commit();
			status=true;
			
		}catch(HibernateException ex){
			session.getTransaction().rollback();
		}
		session.close();
		return status;
	}
	
	public boolean AddRoom_participants(Room room,List<Participants> plist)
	{
		Participants par=new Participants();
		session=factory.openSession();
		session.beginTransaction();
		try{
			
			//auth.setBook(book);
			par.setRoom(room);
			room.setPar(plist);
			
			session.save(room);
			session.getTransaction().commit();
			status = true;
		}catch(HibernateException ex){
			session.getTransaction().rollback();
		}
		session.close();
		return status;
	}
	
	
	
}
