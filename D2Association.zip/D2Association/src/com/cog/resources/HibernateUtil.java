package com.cog.resources;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateUtil {

	//private static SessionFactory factory;
	@SuppressWarnings("deprecation")
	public static SessionFactory GetFactory()
	{
		return new Configuration().configure("com/cog/resources/hibernate.cfg.xml").buildSessionFactory();
	}
}
