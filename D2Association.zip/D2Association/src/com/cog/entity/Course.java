package com.cog.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;


@Entity
public class Course {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="Customer_Id")
	private int CId;
	@Column(name="Course_Name")
	private String CName;
	
	@ManyToMany(mappedBy="clist")
	
	private List<Trainee> tlist;
	
	
	public int getCId() {
		return CId;
	}
	public void setCId(int cId) {
		CId = cId;
	}
	public String getCName() {
		return CName;
	}
	public void setCName(String cName) {
		CName = cName;
	}
	public List<Trainee> getTlist() {
		return tlist;
	}
	public void setTlist(List<Trainee> tlist) {
		this.tlist = tlist;
	}
	
	
	
}
