package com.cog.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Participants {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="Participant_Id")
	private int PId;
	@Column(name="Participant_name")
	private String Pname;
	@ManyToOne
	@JoinColumn(name="Room_Id")
	private Room room;
	public Room getRoom() {
		return room;
	}
	public void setRoom(Room room) {
		this.room = room;
	}
	public int getPId() {
		return PId;
	}
	public void setPId(int pId) {
		PId = pId;
	}
	public String getPname() {
		return Pname;
	}
	public void setPname(String pname) {
		Pname = pname;
	}

	
}
